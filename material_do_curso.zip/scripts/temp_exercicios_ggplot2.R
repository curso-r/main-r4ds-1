# Exercícios --------------------------------------------------------------

# a. Crie um gráfico de dispersão da nota do imdb pelo orçamento.
#dicas: ggplot() aes() geom_point()

# b. Pinte todos os pontos do gráfico de azul. (potencial pegadinha =P)

# Exercício ---------------------------------------------------------------

# Faça um gráfico do orçamento médio dos filmes ao longo dos anos.
# dicas: group_by() summarise() ggplot() aes() geom_line()

# Exercícios --------------------------------------------------------------

# a. Transforme o gráfico do exercício anterior em um gráfico de barras.

# b. Refaça o gráfico apenas para filmes de 1989 para cá.]]

# Exercícios --------------------------------------------------------------

# a. Faça um gráfico de barras empilhados cruzando cor e classificacao
# dica: geom_col(position = "fill") 

# b. adicione + scale_fill_brewer(palette = "Set3")  ao grafico

# Exercícios --------------------------------------------------------------

#a. Descubra quais são os 5 atores que mais aparecem na coluna ator_1.
# dica: count() top_n()

#b. Faça um boxplot do lucro dos filmes desses atores.